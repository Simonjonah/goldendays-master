<!DOCTYPE html>
<html>
<head>
    <title>Golden Destiny Academy Terminal Result</title>
</head>
<style>
    /* table{
    width:200px;
    height:auto;
    table-layout:fixed;
} */
td {
  height: 3px; /* Adjust the height as per your requirements */
}
tr {
  height: 3px; /* Adjust the height as per your requirements */
}

td {
    margin: 0px;
  padding-top: 0px;
  padding-bottom: 0px;
}
table, th {
    border: 1px solid black;
  border-collapse: collapse;
}
table, td {
  border: 1px solid black;
  border-collapse: collapse;
  font-size: 12px;
  text-align: center;
  /* height:10px;
  padding: 0px;
  margin: 0px; */
}
table .b{
    border-style: none;
}
/* .dayopen, .von{
    font-size: 15px;
} */
table, tr, td{
    margin: 0;
    padding: 0;
}

</style>
<body>
       
   <?php
       $total_score = 0;
   ?>
        
        <?php $__currentLoopData = $getyour_results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $getyour_result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($getyour_result->status == 'approved'): ?>
                
            <?php else: ?>
                
            <?php endif; ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
  
    <table class="table">

        <tr>
            <th style="text-align: center; width: 120px; height: 100px; padding: 0px">
                
            </th>

            <th style="text-align: center; width: 450px;"><h1>GOLDEN SCHOOL ACADEMY</h1>
                <p style="font-weight: normal; margin-bottom: -8px;">Golden Destiny Academy Street
                    Housing extention Uyo, Akwa Ibom State, Nigeria</p>
                <p  style="font-weight: normal; font-style:italic">Motor: Fostering Creativity and Development</p> 
            </th>
                
            <th style="text-align: center; width: 120px;">
                Student Image
            </th>
        </tr>
       

            <tr>
                <th colspan="2" style="text-align: center; text-transform: uppercase;"><?php echo e($getyour_result->term); ?> REPORT FOR <?php echo e($getyour_result->academic_session); ?> <br>
                   UDO SIMON UDO
                </th>
                <th>-</th>
            </tr>
    </table>

        
        

        <table id="myTable">
            <tr>
              <th>AFFECTIVE DOMAIN (UBJECT OFFERED) </th>
              <th>CA 1</th>
              <th>CA 2</th>
              <th>CA 3</th>
              <th>EXAMS</th>
              <th>TOTAL</th>
              <th>GRADE</th>
              <th>SUBJECT AVERAGE</th>
              
            </tr>
            <tr>

              <td>-</td>
              <td>20</td>
              <td>20</td>
              <td>10</td>
              <td>50</td>
              <td>100</td>
              <td>-</td>
              <td>-</td>

            </tr>
       
            <?php $__currentLoopData = $getyour_results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $getyour_result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($getyour_result->subjectname); ?></td>
                <td><?php echo e($getyour_result->test_1); ?></td>
                <td><?php echo e($getyour_result->test_2); ?></td>
                <td><?php echo e($getyour_result->test_3); ?></td>
                <td><?php echo e($getyour_result->exams); ?></td>
                <td><?php echo e($getyour_result->test_1 + $getyour_result->test_2 + $getyour_result->test_3 + $getyour_result->exams); ?></td>
                <td><?php if($getyour_result->test_1 + $getyour_result->test_2 + $getyour_result->test_3 + $getyour_result->exams > 79): ?>
                    <td>a</td>
                
                    <?php elseif($getyour_result->test_1 + $getyour_result->test_2 + $getyour_result->test_3 + $getyour_result->exams > 69): ?>
                    <td>a</td>
                    <?php elseif($getyour_result->test_1 + $getyour_result->test_2 + $getyour_result->test_3 + $getyour_result->exams > 59): ?>
                    <td>a</td>
                    <?php elseif($getyour_result->test_1 + $getyour_result->test_2 + $getyour_result->test_3 + $getyour_result->exams > 49): ?>
                    <td>a</td>
                    <?php elseif($getyour_result->test_1 + $getyour_result->test_2 + $getyour_result->test_3 + $getyour_result->exams > 49): ?>
                    <td>a</td>
                    <?php elseif($getyour_result->test_1 + $getyour_result->test_2 + $getyour_result->test_3 + $getyour_result->exams > 39): ?>
                    <td>a</td>
                    <?php else: ?>
                    <td>a</td>
                <?php endif; ?></td>

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                
            
                
                
                
                
            
                
           
            
                <td>Total</td>
                <td>-</td>
                <td>-</td>
                <td>-</td>
                <td>-</td>
                <td><b>TOTAL SCORE</b></td>
                <td>-</td>
                <td><b>687.9</b></td>
              </tr>

          </table>


          


          <table>
            <tr>
                <td>REG CODE:</td>
                <td><?php echo e($getyour_result->regnumber); ?></td>
                <td>SEX:</td>
                <td><?php echo e($getyour_result->user['gender']); ?></td>
                <td>TOTAL SCORE OBTAINABLE:</td>
                
                <td>NO. OF DISTINGTIONS (A-B):</td>
                <td>7A's, 3B's</td>
            </tr>
    
            <tr>
                <td>CLASS:</td>
                <td><?php echo e($getyour_result->classname); ?></td>
                <td>TERM:</td>
                <td><?php echo e($getyour_result->term); ?> </td>
                <td>SCORE OBTAINED:</td>
                <td><?php echo e($total_score); ?></td>
    
                <td>NO. OF CREDITS (C-D):</td>
                <td>6C's 3D's</td>
            </tr>
            <tr>
                <td>AGE:</td>
                <td><?php echo e($getyour_result->user['dob']); ?></td>
                <td colspan="2"></td>
               
                <td>PERCENTAGE:</td>
                <td><?php echo e($total_score/100); ?></td>
                <td>PUPIL'S GRADE IN CLASS:</td>
                <td>B</td>
            </tr>
            
        
    
         </table>
    
          
          
        <table class="dayopen" style="margin-top: 10px; " >
            <tr>
                <td class="von">Days School Opens:</td>
                <td class="von">120</td>
                <td class="von">No of Days Present:</td>
                <td class="von">120</td>
                <td class="von">Next Term Begins:</td>
                <td class="von">28th January, 2023</td>
            </tr>

           
            </table>

            <table style="margin-top: 2px;">
                <tr>
                    <td>Class Teacher's Comment</td>
                    <td>Precious is an intelligent and active class participant. She has shown 								
                        improvement in some of her subjects .There is still lots of room for  								
                       growth and improvement. We are working on improving her focus and 								
                       drive in the coming term.								
                    </td>
                    <td>Signature: TOT SUBJECT</td>
                </tr>

                <tr>
                    <td>Head Teacher's Comment</td>
                    <td>Precious is an intelligent and active class participant. She has shown 								
                        improvement in some of her subjects .There is still lots of room for  								
                       growth and improvement. We are working on improving her focus and 								
                       drive in the coming term.								
                    </td>
                    <td>Signature: </td>
                </tr>
        
        
            </table>


         
  
</body>
</html>
<?php /**PATH C:\xampp\htdocs\goldendays-master\resources\views/dashboard/guardian/pdf1.blade.php ENDPATH**/ ?>
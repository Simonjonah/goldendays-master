<?php echo $__env->make('dashboard.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('dashboard.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
   <!-- Main content -->
   <section class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-3">
          <a href="<?php echo e(url('web/checkyourquery')); ?>" class="btn btn-primary btn-block mb-3">Back to Inbox</a>

          <div class="card">
            <div class="card-header">
              <h3 class="card-title">Folders</h3>

              <div class="card-tools">
                <button type="button" class="btn btn-tool" data-card-widget="collapse"><i class="fas fa-minus"></i>
                </button>
              </div>
            </div>
            <div class="card-body p-0">
              <ul class="nav nav-pills flex-column">
                <li class="nav-item active">
                  <a href="<?php echo e(url('web/checkyourquery')); ?>" class="nav-link">
                    <i class="fas fa-inbox"></i> Inbox
                    <span class="badge bg-primary float-right">8</span>
                  </a>
                </li>
                <li class="nav-item">
                  <a href="" class="nav-link">
                    <i class="far fa-envelope"></i> Activities Submited
                    <span class="badge bg-info float-right">1</span>

                    
                  </a>
                </li>
                
              </ul>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">Labels</h3>

              <div class="card-tools">
                
              </div>
            </div>
            <!-- /.card-header -->
            
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
        <div class="col-md-9">
          <div class="card card-primary card-outline">
            <div class="card-header">
              <h3 class="card-title">Add Your Activities</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              

                <form action="<?php echo e(url('web/createclassactivity')); ?>" method="post" enctype="multipart/form-data">

                <?php echo csrf_field(); ?>
                
                <?php if(Session::get('success')): ?>
                  <div class="alert alert-success">
                      <?php echo e(Session::get('success')); ?>

                  </div>
                  <?php endif; ?>

                  <?php if(Session::get('fail')): ?>
                  <div class="alert alert-danger">
                  <?php echo e(Session::get('fail')); ?>

                  <?php endif; ?>
                <div class="form-group">
                  <input type="hidden" class="form-control" name="user_id" value="<?php echo e(Auth::guard('web')->user()->id); ?>" placeholder=":">
                  
                  <input type="text" class="form-control" name="subject" value="" placeholder="Subject">
                </div>

                <div class="form-group">
                    <input type="text" class="form-control" name="topic" value="" placeholder="Topic">
                  </div>

                  <div class="form-group">
                    <input type="url" class="form-control" name="youtube" value="" placeholder="You Tube Link">
                  </div>
                <div class="form-group">
                    <textarea id="compose-textarea" name="messages" class="form-control" style="height: 300px">
                     
                     
                      
                    </textarea>
                </div>

                <div class="card-footer">
                  <div class="float-right">
                    
                    <button type="submit" class="btn btn-primary"><i class="far fa-envelope"></i> Send</button>
                  </div>
                  
                </div>
              </form>
              
              
            </div>
            <!-- /.card-body -->
            <div class="card-footer">
              <div class="float-right">
                
                
              </div>
              
            </div>
            <!-- /.card-footer -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </div><!-- /.container-fluid -->
  </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <div class="float-right d-none d-sm-block">
      <b>Version</b> 3.0.5
    </div>
    <strong>Copyright &copy; 2023 <a href="httpS://golderndayschools.com">Golderndays</a>.</strong> All rights
    reserved.
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->




<script src="<?php echo e(asset('assets/plugins/jquery/jquery.min.js')); ?>"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo e(asset('assets/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo e(asset('assets/dist/js/adminlte.min.js')); ?>"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo e(asset('assets/dist/js/demo.js')); ?>"></script>
<!-- Summernote -->
<script src="<?php echo e(asset('assets/plugins/summernote/summernote-bs4.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/assets/dist/js/demo.js')); ?>"></script>

<script>
  $(function () {
    $("#example1").DataTable({
      "responsive": true, "lengthChange": false, "autoWidth": false,
      "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });
  });
</script>

<script>
    $(function () {
      //Add text editor
      $('#compose-textarea').summernote()
    })
  </script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\goldendays-master\resources\views/dashboard/addaclassctivities.blade.php ENDPATH**/ ?>
<?php echo $__env->make('dashboard.guardian.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Main Sidebar Container -->
  <?php echo $__env->make('dashboard.guardian.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            
          </div>
          <div class="col-sm-6">
            
            <ol class="breadcrumb float-sm-right">
              Class
              
               
                  
               
           
              
            </ol>
            
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            

            <div class="card">
              <div class="card-header">
                
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                
                <div class="col-lg-6 col-md-6 col-sm-12">
                 
                  
                    <?php $__currentLoopData = $view_classpayments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $view_classpayment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <form method="POST" action="<?php echo e(route('pay')); ?>" id="paymentForm">
                        <?php echo e(csrf_field()); ?>

                        
                       

                        <div class="form-group">
                            <label for="">Class</label>
                            <select name="classname" class="form-control" id="">
                                <option value="<?php echo e($view_classpayment->classname); ?>"><?php echo e($view_classpayment->classname); ?></option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="">Term</label>
                            <select name="term" class="form-control" id="">
                                <option value="<?php echo e($view_classpayment->term); ?>"><?php echo e($view_classpayment->term); ?></option>
                            </select>
                        </div>
                      

                    
                        <div class="form-group">
                          <label for="">Feeding Fees</label>
                          <input class="form-control" value="<?php echo e($view_classpayment->amount); ?>" name="amount" placeholder="Feeding Fee" />
                      </div>
                       
                      <div class="form-group">
                        <label for="">Route</label>
                        <input class="form-control" value="<?php echo e($view_classpayment->address); ?>" name="address" placeholder="Route" />
                    </div>
                      <div class="form-group">
                        
                        <input class="form-control" value="<?php echo e($view_classpayment->feeding); ?>" name="feeding" placeholder="Name" />
                    </div>
                        <div class="form-group">
                            <input class="form-control" value="<?php echo e(Auth::guard('guardian')->user()->email); ?>" name="email" type="email" placeholder="Your Email" />
                        </div>
                        <div class="form-group">
                          <input class="form-control" value="<?php echo e(Auth::guard('guardian')->user()->phone); ?>" name="phone" type="tel" placeholder="Phone number" />
                          <input class="form-control" value="<?php echo e(Auth::guard('guardian')->user()->id); ?>" name="guardian_id" type="number" placeholder="Phone number" />
                          
                        </div>
                        
                        <input type="submit" class="btn btn-lg btn-primary" value="Pay" />
                        <input class="form-control" value="<?php echo e($pay_fees->fname); ?>" name="fname" type="tel" placeholder="" />
                        <input class="form-control" value="<?php echo e($pay_fees->middlename); ?>" name="middlename" type="text" placeholder="" />
                        <input class="form-control" value="<?php echo e($pay_fees->surname); ?>" name="surname" type="text" placeholder="" />
                        <input class="form-control" value="<?php echo e($pay_fees->id); ?>" name="student_id" type="text" placeholder="" />
                        <input class="form-control" value="<?php echo e($pay_fees->section); ?>" name="section" type="text" placeholder="" />
                   
                    <h3>Total: N <?php echo e($view_classpayment->amount + $view_classpayment->tuition + $view_classpayment->pta_amount + $view_classpayment->extracuri_fee + $view_classpayment->medicals + $view_classpayment->dev_amount + $view_classpayment->bookamount + $view_classpayment->uniforms_amount + $view_classpayment->form_amount); ?></h3>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </form>
                    
                    <div class="col-lg-6 col-md-6 col-sm-12">
                      <h3></h3>
                    </div>
                </div>
                
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <div class="float-right d-none d-sm-block">
      <b>Version</b> 3.0.5
    </div>
    <strong>Copyright &copy; 2023 <a href="https://goldenschools.com">Goldenschools.com</a>.</strong> All rights
    reserved.
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->


<script src="<?php echo e(asset('assets/plugins/jquery/jquery.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/datatables-buttons/js/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/datatables-buttons/js/buttons.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/jszip/jszip.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/pdfmake/pdfmake.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/pdfmake/vfs_fonts.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/datatables-buttons/js/buttons.html5.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/datatables-buttons/js/buttons.print.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/datatables-buttons/js/buttons.colVis.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/dist/js/adminlte.min.js?v=3.2.0')); ?>"></script>

<script src="<?php echo e(asset('assets/dist/js/demo.js')); ?>"></script>

<script>
  $(function () {
    $("#example1").DataTable({
      "responsive": true, "lengthChange": false, "autoWidth": false,
      "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });
  });
</script>




</body>
</html>
<?php /**PATH C:\xampp\htdocs\goldendays-master\resources\views/dashboard/guardian/paybuservicefee.blade.php ENDPATH**/ ?>
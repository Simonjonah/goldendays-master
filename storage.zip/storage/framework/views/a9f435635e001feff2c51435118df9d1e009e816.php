
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Admin |  Print</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Bootstrap 4 -->

  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/fontawesome-free/css/all.min.css')); ?>">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/dist/css/adminlte.min.css')); ?>">

  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
  <style>
    /* .watermark{
      background-image: url('../assets/dist/img/AdminLTELogo.jpg');
      background-position: center; 
      background-repeat: no-repeat;
    } */

  .break-after {
    page-break-after: always;
  }

  #watermark {
    flow: static(watermarkflow);
    font-size: 120px;
    opacity: 0.5;
    transform: rotate(-30deg);
    text-align: center;
  }

  @page {
     @prince-overlay {
        content: flow(watermarkflow)
     }
  }
  </style>



</head>
<body>
<div class="wrapper">
  <!-- Main content -->





  <section class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-12">
          <div class="callout callout-info">
            
            
          </div>

          <!-- Main content -->
          <div class="invoice p-3 mb-3">
            <!-- title row -->
            <div class="row">
              <div class="col-12">
                
              </div>
              <!-- /.col -->
            </div>
            <!-- info row -->
            <div class="row invoice-info">
              <div class="col-sm-4 invoice-col">
                <img style="width: 200px; height: 100px;" src="<?php echo e(asset('assets/dist/img/AdminLTELogo.jpg')); ?>" alt="">
                  <address>
                    <?php if(Auth::guard()->user()->centername == 'Uyo'): ?>
                    <strong>BRIXTONN SCHOOLS</strong><br>
                    Unit 13 F-Line Ewet Housing Estate,<br>
                     Uyo, Akwa Ibom, Nigeria <br>
                    +234 816 7930 965 <br>
                    info@brixtonnschools.com.ng
                    
                    <?php else: ?>
                    <strong>BRIXTONN SCHOOLS</strong><br>
                    54 Nsikak Eduok Avenue,<br>
                    Uyo, Akwa Ibom State<br>
                    Phone: 08167930965<br>
                    Email: info@imfiacademy.edu.ng
                    <?php endif; ?>
                    
                  </address>
              </div>

              
              <div class="col-sm-4 invoice-col">
                  
                <b> ID:</b> <?php echo e(Auth::guard('guardian')->user()->ref_no1); ?><br>
                <b>Admission Number</b> <?php echo e(Auth::guard('guardian')->user()->regnumber); ?><br>
                <b>Section:</b> <?php echo e(Auth::guard('guardian')->user()->section); ?><br>
                <b>Class</b> <?php echo e(Auth::guard('guardian')->user()->classname); ?><br>
                <b>Gender</b> <?php echo e(Auth::guard('guardian')->user()->gender); ?><br>
                <b>Centername</b> <?php echo e(Auth::guard('guardian')->user()->centername); ?><br>
                <b>Term</b> <?php echo e(Auth::guard('guardian')->user()->entrylevel); ?><br>
                <b>Session</b> <?php echo e(Auth::guard('guardian')->user()->academic_session); ?><br>
              </div>
              <!-- /.col -->

              <div class="col-sm-4 invoice-col">
               

                <small class="float-right"> <img style="width: 200px; height: 200px;" src="<?php echo e(asset('/public/../'.Auth::guard('guardian')->user()->images)); ?>" class="" alt="User Image"></small>
              </div>
            </div>
            

            <!-- /.row -->
            
            <!-- Table row -->
            <div class="row">
              <div class="col-12 table-responsive">
               
                <table class="table table-striped">
                  <thead>
                  <tr>
                    <th>Subjects</th>
                
                    <th>Test</th>
                    <th>Exams</th>
                    <th>Total</th>
                    <th>Grade</th>
                    
                    

                  </tr>
                  </thead>
                  <tbody>
                    
                  <?php $__currentLoopData = $getyour_results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $getyour_result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      
                      
                      <tr>
                        <td style="width: 400px;height: 10px"><?php echo e($getyour_result->subjectname); ?></td>
                        <td><?php echo e($getyour_result->test_1 + $getyour_result->test_2 + $getyour_result->test_3); ?></td>
                    
                        <td><?php echo e($getyour_result->exams); ?></td>
                        <td><?php echo e($getyour_result->test_1 + $getyour_result->exams); ?></td>
                      
                        <td><?php if($getyour_result->test + $getyour_result->exams > 69): ?>
                          <p>A</p>
                         
                          <?php elseif($getyour_result->test + $getyour_result->exams > 59): ?>
                          <p>B</p>
                          <?php elseif($getyour_result->test + $getyour_result->exams > 49): ?>
                          <p>c</p>
                          <?php elseif($getyour_result->test + $getyour_result->exams > 44): ?>
                          <p>D</p>
                          <?php elseif($getyour_result->test + $getyour_result->exams > 40): ?>
                          <p>E</p>
                          <?php elseif($getyour_result->test + $getyour_result->exams > 39): ?>
                          <p>F</p>
                          <?php else: ?>
                          <p>F</p>
                        <?php endif; ?></td>

                        

                      </tr> 
                        
                      

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
              
                  
                        
                        
                        
                  </tbody>

                </table>
                <p>Registrar</p>
                <img src="<?php echo e(asset('assets/dist/img/signature.png')); ?>" alt="">

              </div>
              <!-- /.col -->
            </div>
           

            <!-- this row will not appear when printing -->
            <div class="row no-print">
              <div class="col-12">
                
                
              </div>
            </div>
          </div>
          <!-- /.invoice -->
        </div><!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </section>
  <!-- /.content -->
</div>
<!-- ./wrapper -->

<script type="text/javascript"> 
  window.addEventListener("load", window.print());
</script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\goldendays-master\resources\views/dashboard/guardian/yourresult.blade.php ENDPATH**/ ?>
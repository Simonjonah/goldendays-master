
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>AdminLTE 3 | Invoice Print</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Bootstrap 4 -->

  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/fontawesome-free/css/all.min.css')); ?>">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css') }}">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo e(asset('assets/dist/css/adminlte.min.css')); ?>">

  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
</head>
<body>
<div class="wrapper">
  <!-- Main content -->
  <section class="invoice">
    <!-- title row -->
    <div class="row">
      
      <!-- /.col -->
    </div>
    <!-- info row -->
    <div class="row invoice-info">
      <div class="col-sm-2 invoice-col">
        <img style="width: 100px; height: 100px;" src="<?php echo e(asset('images/sch14.png')); ?>" alt=""> <br>

      </div>
      <!-- /.col -->
      <div class="col-sm-8 invoice-col">
        <h1><strong>GOLDERN DESTINY SCHOOLS</strong></h1>
                  
        Golden Destiny Academy Road.
        Off Senator Akon Eyakenyi Street,
        Off General Edet Akpan Ave, 520101, Uyo
      </div>
      <!-- /.col -->
      <div class="col-sm-2 invoice-col">
        

      </div>
      <!-- /.col -->
    </div>
  
    <h2 class="text-center">Fee Schedules</h2>

    <div class="row" style="margin-top: 60px;">
      <!-- accepted payments column -->
      <div class="col-12">
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                  <tr>
                    <th>Tuition Fee</th>
                    <th>Medicals</th>
                    <th>Extra Curricular </th>
                    <th>Term </th>
                    <th>Books & Worksheet</th>
      
                    <th>Class</th>
                    <th>Development Fee</th>
                    <th>Uniforms Amount</th>
                    <th>PTA FEE</th>
                    <th>Form Amount</th>
                    <th>Date</th>
      
                   
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $print_allfees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $print_allfee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                      <td>₦<?php echo e($print_allfee->amount); ?></td>
                      <td>₦<?php echo e($print_allfee->medicals); ?></td>
          
                      <td>₦<?php echo e($print_allfee->extracuri_fee); ?></td>
                      <td><?php echo e($print_allfee->term); ?></td>
                      <td>₦<?php echo e($print_allfee->bookamount); ?></td>
                      <td><?php echo e($print_allfee->classname); ?></td>
                      
                    
                      <td>₦<?php echo e($print_allfee->dev_amount); ?></td>
                      <td>₦<?php echo e($print_allfee->uniforms_amount); ?></td>
                      <td> ₦<?php echo e($print_allfee->pta_amount); ?></td>
                      <td>₦ <?php echo e($print_allfee->form_amount); ?></td>
                      <td><?php echo e($print_allfee->created_at->format('D d, M Y, H:i')); ?></td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                
                </tbody>
              </table>
        </div>
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
  </section>
  <!-- /.content -->
</div>
<!-- ./wrapper -->

<script type="text/javascript"> 
  window.addEventListener("load", window.print());
</script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\goldendays-master\resources\views/dashboard/account/printfeeall.blade.php ENDPATH**/ ?>
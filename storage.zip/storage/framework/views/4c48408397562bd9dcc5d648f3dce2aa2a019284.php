<?php echo $__env->make('dashboard.admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Main Sidebar Container -->
  <?php echo $__env->make('dashboard.admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>DataTables</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">DataTables</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            

            <div class="card">
              <div class="card-header">
                <h3 class="card-title">DataTable with default features</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>Surname</th>
                    <th>Middlename</th>
                    <th>Lastname</th>
                    
                    <th>View</th>
                    <th>Edit</th>
                    <th>Status</th>
                    <th>Reject</th>
                 
                    <th>Suspend</th>
                    <th>Approved</th>
                    
                    <th>Delete</th>
                    <th>Date</th>

                  </tr>
                  </thead>
                  <tbody>

                    <?php $__currentLoopData = $view_lessonnotes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $view_lessonnote): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      
                      <tr>
                        <td><?php echo e($view_lessonnote->user['surname']); ?></td>
                        <td><?php echo e($view_lessonnote->user['middlename']); ?></td>
                        <td><?php echo e($view_lessonnote->user['fname']); ?></td>
                        
                        <td><a href="<?php echo e(url('admin/viewsinglelesson/'.$view_lessonnote->slug)); ?>"
                            class='btn btn-default'>
                             <i class="far fa-eye"></i>
                         </a></td>
                         <td><a href="<?php echo e(url('admin/editsinglenotesad/'.$view_lessonnote->id)); ?>"
                          class='btn btn-info'>
                           <i class="far fa-edit"></i>
                       </a></td>
                       <td><?php if($view_lessonnote->status == null): ?>
                        <span class="badge badge-secondary"> In progress</span>
                       <?php elseif($view_lessonnote->status == 'suspend'): ?>
                       <span class="badge badge-warning"> Suspended</span>
                       <?php elseif($view_lessonnote->status == 'reject'): ?>
                       <span class="badge badge-danger"> Rejected</span>
                       <?php elseif($view_lessonnote->status == 'approved'): ?>
                       <span class="badge badge-success">Approved</span>

                     
                       
                       <?php endif; ?></td>
                  

                       <th><a href="<?php echo e(url('admin/rejectlessonnote/'.$view_lessonnote->slug)); ?>" class="btn btn-sm bg-teal">
                        <i class="fas fa-user"></i>
                      </a></th>
                      
                      </a></th><th><a href="<?php echo e(url('admin/suspendlessonnotes/'.$view_lessonnote->slug)); ?>" class="btn btn-sm bg-teal">
                        <i class="fas fa-comments"></i>
                      </a></th>

                      <th> <a href="<?php echo e(url('admin/lesonapprove/'.$view_lessonnote->slug)); ?>" class="btn btn-sm btn-primary">
                        <i class="fas fa-user"></i> 
                      </a></th>
                       <td><a href="<?php echo e(url('admin/deleteslessonnote/'.$view_lessonnote->slug)); ?>"
                        class='btn btn-danger'>
                         <i class="far fa-trash-alt"></i>
                     </a></td>
                        
                     <td><?php echo e($view_lessonnote->created_at->format('D d, M Y, H:i')); ?></td>

                      </tr>
                      
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 
                 
                   
                  </tbody>
                  <tfoot>
                    <tr>
                    <th>Surname</th>
                    <th>Middlename</th>
                    <th>Lastname</th>
                    
                    <th>View</th>
                    <th>Edit</th>
                    <th>Status</th>
                    <th>Reject</th>
                 
                    <th>Suspend</th>
                    <th>Approved</th>
                    
                    <th>Delete</th>
                    <th>Date</th>

                    </tr>
                  </tfoot>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <?php echo $__env->make('dashboard.admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\goldendays-master\resources\views/dashboard/admin/viewlessonnotesad.blade.php ENDPATH**/ ?>
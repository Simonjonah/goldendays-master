<?php echo $__env->make('dashboard.admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('dashboard.admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Content Wrapper. Contains page content -->
 <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row">
            <div class="col-12">
              <img style="width: 200px; height: 80px;" class="fas fa-globe float-left" src="<?php echo e(asset('assets/dist/img/AdminLTELogo.jpg')); ?>" alt="">

              <h2 class="page-header text-center">
                 Golden Academy Schools
              </h2>
            </div>
            <!-- /.col -->
          </div>
          
      </div><!-- /.container-fluid -->
      
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-3">

            <!-- Profile Image -->
            <div class="card card-primary card-outline">
              <div class="card-body box-profile">
                <div class="text-center">
                  <img style="width: 100%; height: 200px;" class="profile-user-img img-fluid"
                       src="<?php echo e(asset('/public/../'.$view_singteachers->images)); ?>"
                       alt="User profile picture">
                </div>

                <h3 class="profile-username text-center"><?php echo e($view_singteachers->fname); ?> <?php echo e($view_singteachers->middlename); ?>  <?php echo e($view_singteachers->surname); ?></h3>

                <p class="text-muted text-center"> <?php echo e($view_singteachers->email); ?></p>

                <span class="badge badge-secondary"><?php echo e($view_singteachers->status); ?></span>
                <?php if($view_singteachers->role == 'teacher'): ?>
                <span class="badge badge-secondary">In Progress</span>
                <?php elseif($view_singteachers->role == 'sacked'): ?>
                <span class="badge badge-danger">Sacked</span>
                <?php elseif($view_singteachers->role == 'suspend'): ?>
                <span class="badge badge-warning">Suspended</span>
                  <?php else: ?>
                  <span class="badge badge-success">Employed</span>
                <?php endif; ?>
              
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->

            <!-- About Me Box -->
            <div class="card card-primary">
              
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
          <div class="col-md-9">
            <div class="card">
              <div class="card-header p-2">
                <ul class="nav nav-pills">
                  
                  

                </ul>
              </div><!-- /.card-header -->
              <div class="card-body">
                <form class="form-horizontal" action="<?php echo e(url('admin/settingsupdate/'.$view_singteachers->id)); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    
                    <?php echo method_field('PUT'); ?>

                    <div class="form-group row">
                      <label for="inputName" class="col-sm-2 col-form-label"> First Name</label>
                      <div class="col-sm-10">
                        <input type="text" name="fname" value="<?php echo e($view_singteachers->fname); ?>" class="form-control" id="inputName" placeholder="First Name">
                      </div>
                    </div>
                    <div class="form-group row">
                      <label for="inputName" class="col-sm-2 col-form-label"> Middle Name</label>
                      <div class="col-sm-10">
                        <input type="text" name="lname" value="<?php echo e($view_singteachers->middlename); ?>" class="form-control" id="inputName" placeholder="Last Name">
                      </div>
                    </div>
                    <div class="form-group row">
                      <label for="inputName" class="col-sm-2 col-form-label"> Last Name</label>
                      <div class="col-sm-10">
                        <input type="text" name="lname" value="<?php echo e($view_singteachers->surname); ?>" class="form-control" id="inputName" placeholder="Last Name">
                      </div>
                    </div>
                    <div class="form-group row">
                      <label for="inputEmail" class="col-sm-2 col-form-label">Email</label>
                      <div class="col-sm-10">
                        <input type="email" name="email" value="<?php echo e($view_singteachers->email); ?>" class="form-control" id="inputEmail" placeholder="Email">
                      </div>
                    </div>
                    <div class="form-group row">
                      <label for="inputName2" value="" class="col-sm-2 col-form-label">Address</label>
                      <div class="col-sm-10">
                        <input type="text" class="form-control" value="<?php echo e($view_singteachers->phone); ?>" name="phone" id="inputName2" placeholder="phone">
                      </div>
                    </div>
                    

                    <div class="form-group row">
                      <label for="inputName2"  class="col-sm-2 col-form-label">Centername</label>
                      <div class="col-sm-10">
                        <input type="text" class="form-control" value="<?php echo e($view_singteachers->centername); ?>" name="profileimage" id="inputName2" placeholder="profileimage">
                      </div>
                    </div>
                    <div class="form-group row">
                      <label for="inputExperience" class="col-sm-2 col-form-label">Class</label>
                      <div class="col-sm-10">
                        <input type="text" name="phone" value="<?php echo e($view_singteachers->classname); ?>" class="form-control" id="inputSkills" placeholder="Phone">

                      </div>
                    </div>
                    <div class="form-group row">
                      <label for="inputSkills" class="col-sm-2 col-form-label">Phone</label>
                      <div class="col-sm-10">
                        <input type="number" name="phone" value="<?php echo e($view_singteachers->phone); ?>" class="form-control" id="inputSkills" placeholder="Phone">
                      </div>
                    </div>

                    <div class="form-group row">
                      <label for="inputSkills" class="col-sm-2 col-form-label">Section</label>
                      <div class="col-sm-10">
                        <input type="text" name="phone" value="<?php echo e($view_singteachers->section); ?>" class="form-control" id="inputSkills" placeholder="Section">
                      </div>
                    </div>
                    
                    <div class="form-group row">
                      <div class="offset-sm-2 col-sm-10">
                        <a class="btn btn-primary" href="../lecturersprint/<?php echo e($view_singteachers->ref_no1); ?>">Print</a>
                        <a href="<?php echo e(url('admin/viewsingleteacher/'.$view_singteachers->ref_no1)); ?>" class="btn btn-default"><i class="fas fa-eye"></i>View</a>
                        <a href="<?php echo e(url('admin/editteacher/'.$view_singteachers->ref_no1)); ?>" class="btn btn-info"><i class="fas fa-edit"></i>Edit</a>
                        <a href="<?php echo e(url('admin/teacherapprove/'.$view_singteachers->ref_no1)); ?>" class="btn btn-success"><i class="fas fa-user"></i>Approved</a>
                        <a href="<?php echo e(url('admin/teachersuspend/'.$view_singteachers->ref_no1)); ?>" class="btn btn-secondary"><i class="fas fa-user"></i>Suspend</a>
                        <a href="<?php echo e(url('admin/teachersacked/'.$view_singteachers->ref_no1)); ?>" class="btn btn-danger"><i class="fas fa-user"></i>Sacked</a>
                        <a href="<?php echo e(url('admin/teacherquery/'.$view_singteachers->ref_no1)); ?>" class="btn btn-warning"><i class="fas fa-user"></i>Query</a>
                       
                        <th><a href="<?php echo e(url('admin/teachersprint/'.$view_singteachers->ref_no1)); ?>" class="btn btn-primary"><i class="fas fa-print"></i></a></th>
                         <td><a href="<?php echo e(url('admin/teacherdelete/'.$view_singteachers->ref_no1)); ?>"
                          class='btn btn-danger'>
                           <i class="far fa-trash-alt"></i>
                       </a></td>
                        
                      </div>
                    </div>
                  </form>
              </div><!-- /.card-body -->
            </div>
            <!-- /.nav-tabs-custom -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
 </div>
    <?php echo $__env->make('dashboard.admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\goldendays-master\resources\views/dashboard/admin/viewsingleteacher.blade.php ENDPATH**/ ?>
<?php echo $__env->make('dashboard.admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('dashboard.admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
  
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
           
            <!-- Main content -->
            <div class="invoice p-3 mb-3">
              <!-- title row -->
              <div class="row">
                <div class="col-12">
                    <h2 class="page-header">
                        <small class="float-right"><?php echo e($view_studentsubject->created_at->format('D d, M Y, H:i')); ?></small>
                    </h2>
                </div>
                <!-- /.col -->
              </div>
              <!-- info row -->
              <div class="row invoice-info">
                <div class="col-lg-2 col-md-6 col-sm-4 invoice-col">
                    <img style="width: 80px; height: 80px;" src="<?php echo e(asset('images/sch14.png')); ?>" alt=""> <br>

                
                </div> 
                <!-- /.col -->
               <div class="col-lg-8 col-md-6 col-sm-4 invoice-col">
                 
                  <h1><strong>GOLDEN DESTINY ACADEMY</strong></h1>
                  
                  Golden Destiny Academy Road.
                  Off Senator Akon Eyakenyi Street,
                  Off General Edet Akpan Ave, 520101, Uyo
                </div>
                <!-- /.col -->
                <div class="col-lg-2 col-md-6 col-sm-4 invoice-col">
                    <img style="width: 100px; height: 100px;" src="<?php echo e(URL::asset("/public/../$view_studentsubject->images")); ?>" alt="">
                </div>
                <!-- /.col -->
              </div>
              <!-- /.row -->

              <!-- Table row -->
              <div class="row">
                    <div class="col-12 table-responsive">
                      <?php if($view_studentsubject->section === 'Primary'): ?>
                      <form action="<?php echo e(url('admin/createresultsad')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php if(Session::get('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(Session::get('success')); ?>

                        </div>
                        <?php endif; ?>
      
                        <?php if(Session::get('fail')): ?>
                        <div class="alert alert-danger">
                        <?php echo e(Session::get('fail')); ?>

                        <?php endif; ?>
      
                        <table class="table table-striped">
                            <thead>
                            <tr>
                              
                              <th>Subjects</th>
                              <th>Ca 1</th>
                              <th>Ca 2</th>
                              <th>Ca 3</th>
                              <th>Exams</th>
                              
                            </tr>
                            </thead>
                            <tbody>
      
                                <?php $__currentLoopData = $view_teachersubjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $view_teachersubject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <?php if($view_teachersubject->section == 'Primary'): ?>
                                  <tr>
                                      <td><input type="text" value="<?php echo e($view_teachersubject->subjectname); ?>" name="subjectname[]" id=""></td>
                                      <td><input type="number" class="form-control" name="test_1[]" placeholder="Test 1"></td>
                                      <td><input type="number" class="form-control" name="test_2[]" placeholder="Test 2"></td>
                                      <td><input type="number" class="form-control" name="test_3[]" placeholder="Test 3"></td>
                                      <td><input type="number" class="form-control" name="exams[]" placeholder="Exams"></td>
                                      <td><input type="hidden" name="teacher_id" value="<?php echo e(Auth::guard('admin')->user()->id); ?>" placeholder="Teacher ID"></td>
                                      <td><input type="hidden" name="user_id[]" value="<?php echo e($view_studentsubject->id); ?>" placeholder="ID"></td>
                                      <td><input type="hidden" name="term[]" value="<?php echo e($view_studentsubject->term); ?>" placeholder="Term"></td>
                                      <td><input type="hidden" name="academic_session[]" value="<?php echo e($view_studentsubject->academic_session); ?>" placeholder="academic_session"></td>
                                      <td><input type="hidden" name="regnumber[]" value="<?php echo e($view_studentsubject->regnumber); ?>" placeholder="regnumber"></td>
                                      <td><input type="hidden" name="guardian_id[]" value="<?php echo e($view_studentsubject->guardian_id); ?>" placeholder="Parent ID"></td>
                                    <td><input type="hidden" name="classname[]" value="<?php echo e($view_studentsubject->classname); ?>" placeholder="Parent ID"></td>
                                      
                                        
                                    </tr>
                                  <?php else: ?>
                                  
                                          
                                  <?php endif; ?>
      
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
      
                            </tbody>
                          </table>
                      
                        
                </div>
                <!-- /.col -->
              </div>
              <!-- /.row -->
              <button type="submit" class="btn btn-success"><i class="far fa-bell"></i> 
                  Submit 
              </button>
                  
                  <?php else: ?>


                <form action="<?php echo e(url('admin/createresultsad')); ?>" method="post" enctype="multipart/form-data">
                  <?php echo csrf_field(); ?>
                  <?php if(Session::get('success')): ?>
                  <div class="alert alert-success">
                      <?php echo e(Session::get('success')); ?>

                  </div>
                  <?php endif; ?>

                  <?php if(Session::get('fail')): ?>
                  <div class="alert alert-danger">
                  <?php echo e(Session::get('fail')); ?>

                  <?php endif; ?>

                  <table class="table table-striped">
                      <thead>
                      <tr>
                        
                        <th>Subjects</th>
                        <th>Ca 1</th>
                        <th>Ca 2</th>
                        <th>Ca 3</th>
                        <th>Exams</th>
                        
                      </tr>
                      </thead>
                      <tbody>

                          <?php $__currentLoopData = $view_teachersubjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $view_teachersubject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($view_teachersubject->section == 'Secondary'): ?>
                            <tr>
                                <td><input type="text" value="<?php echo e($view_teachersubject->subjectname); ?>" name="subjectname[]" id=""></td>
                                <td><input type="number" class="form-control" name="test_1[]" placeholder="Test 1"></td>
                                <td><input type="number" class="form-control" name="test_2[]" placeholder="Test 2"></td>
                                <td><input type="number" class="form-control" name="test_3[]" placeholder="Test 3"></td>
                                <td><input type="number" class="form-control" name="exams[]" placeholder="Exams"></td>
                                <td><input type="hidden" name="teacher_id[]" value="<?php echo e(Auth::guard('admin')->user()->id); ?>" placeholder="Teacher ID"></td>
                                <td><input type="hidden" name="user_id[]" value="<?php echo e($view_studentsubject->id); ?>" placeholder="ID"></td>
                                <td><input type="hidden" name="term[]" value="<?php echo e($view_studentsubject->term); ?>" placeholder="Term"></td>
                                <td><input type="hidden" name="academic_session[]" value="<?php echo e($view_studentsubject->academic_session); ?>" placeholder="academic_session"></td>
                                <td><input type="hidden" name="regnumber[]" value="<?php echo e($view_studentsubject->regnumber); ?>" placeholder="regnumber"></td>
                                <td><input type="hidden" name="guardian_id[]" value="<?php echo e($view_studentsubject->guardian_id); ?>" placeholder="Parent ID"></td>
                                <td><input type="text" name="classname[]" value="<?php echo e($view_studentsubject->classname); ?>" placeholder="Parent ID"></td>
                                   
                              </tr>
                            <?php else: ?>
                            
                                    
                            <?php endif; ?>

                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      

                      </tbody>
                    </table>
                
                  
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
        <button type="submit" class="btn btn-success"><i class="far fa-bell"></i> 
                    Submit 
                  </button>
        <div class="row">
          
        
          <?php endif; ?>
              </div>
           

                </form>
                
                </div>
              </div>
            </div>
            <!-- /.invoice -->
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>





  
    </div>
    <!-- /.row -->





    

  </div>
  <!-- /.content-wrapper -->

  
 <?php echo $__env->make('dashboard.admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\goldendays-master\resources\views/dashboard/admin/addresultsad1.blade.php ENDPATH**/ ?>
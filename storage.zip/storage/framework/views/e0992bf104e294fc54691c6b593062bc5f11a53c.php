
  <!-- /.navbar -->
<?php echo $__env->make('dashboard.admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- Main Sidebar Container -->
  <?php echo $__env->make('dashboard.admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>DataTables</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">DataTables</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            

            <div class="card">
              <div class="card-header">
                <h3 class="card-title">DataTable with default features</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                    <tr>
                        <th>Subject</th>

                        <th>Topic</th>
                        <th>Youtube</th>
                        
                        
                        <th>Status</th>
                        <th>View</th>
                        <th>Edit</th>
                        <th>Approved</th>
                        <th>Suspend</th>

                        <th>Delete</th>
                        <th>Date</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php if(Session::get('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(Session::get('success')); ?>

                    </div>
                    <?php endif; ?>

                    <?php if(Session::get('fail')): ?>
                    <div class="alert alert-danger">
                    <?php echo e(Session::get('fail')); ?>

                    </div>
                <?php endif; ?>
                    <?php $__currentLoopData = $view_aclassactivitis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $view_aclassactiviti): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr>
                        <td><?php echo e($view_aclassactiviti->subject); ?></td>
                        <td><?php echo e($view_aclassactiviti->topic); ?></td>
                       
                        <td><a href="<?php echo e($view_aclassactiviti->youtube); ?>" target="_blank" rel="noopener noreferrer">Youtube</a></td>
                        
                        
                        
                        <td><?php if($view_aclassactiviti->status == null): ?>
                          <span class="badge badge-secondary"> In Review</span>
                         <?php elseif($view_aclassactiviti->status == 'suspend'): ?>
                         <span class="badge badge-warning"> Suspended</span>
                         <?php elseif($view_aclassactiviti->status == 'reject'): ?>
                         <span class="badge badge-danger"> Rejected</span>
                         <?php else: ?>
                         <span class="badge badge-success">Approved</span>
                         <?php endif; ?></td>

                         
                       <td><a href="<?php echo e(url('admin/viewsingclassactivity/'.$view_aclassactiviti->slug)); ?>"
                            class='btn btn-default'>
                             <i class="far fa-eye"></i>
                         </a></td>
                        <td><a href="<?php echo e(url('admin/editclassactivity/'.$view_aclassactiviti->slug)); ?>"
                         class='btn btn-info'>
                          <i class="far fa-edit"></i>
                      </a></td>
                        <th> <a href="<?php echo e(url('admin/classactivityapproved/'.$view_aclassactiviti->slug)); ?>" class="btn btn-sm btn-primary">
                          <i class="fas fa-user"></i> 
                        </a></th>

                        <th><a href="<?php echo e(url('admin/classactivitysuspend/'.$view_aclassactiviti->slug)); ?>" class="btn btn-sm bg-teal">
                            <i class="fas fa-comments"></i>
                          </a></th>
                       
                      
                         
                       <td><a href="<?php echo e(url('admin/classactivitydelete/'.$view_aclassactiviti->slug)); ?>"
                        class='btn btn-danger'>
                         <i class="far fa-trash-alt"></i>
                     </a></td>
                     <td><?php echo e($view_aclassactiviti->created_at->format('D d, M Y, H:i')); ?></td>
                     

                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 
                 
                   
                  </tbody>
                  <tfoot>
                    <tr>
                      <th>Subject</th>

                      <th>Topic</th>
                      <th>Youtube</th>
                      
                      
                      <th>Status</th>
                      <th>View</th>
                      <th>Edit</th>
                      <th>Approved</th>
                      <th>Suspend</th>

                      <th>Delete</th>
                      <th>Date</th>
                    </tr>
                  </tfoot>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <strong>Copyright &copy; 2023 <a href="https://goldenschools.com">Golden</a></strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b>1.1.1
    </div>
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->


<script src="<?php echo e(asset('assets/plugins/jquery/jquery.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/datatables-buttons/js/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/datatables-buttons/js/buttons.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/jszip/jszip.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/pdfmake/pdfmake.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/pdfmake/vfs_fonts.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/datatables-buttons/js/buttons.html5.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/datatables-buttons/js/buttons.print.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/datatables-buttons/js/buttons.colVis.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/dist/js/adminlte.min.js?v=3.2.0')); ?>"></script>

<script src="<?php echo e(asset('assets/dist/js/demo.js')); ?>"></script>

<script>
  $(function () {
    $("#example1").DataTable({
      "responsive": true, "lengthChange": false, "autoWidth": false,
      "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });
  });
</script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\goldendays-master\resources\views/dashboard/admin/viewclassactivitiesads.blade.php ENDPATH**/ ?>
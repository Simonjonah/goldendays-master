<?php echo $__env->make('dashboard.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('dashboard.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Subjects </h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Subjects</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="callout callout-info">
              <h5><i class="fas fa-info"></i> Note:</h5>
              <span class="text-danger"><?php echo e($view_studentsubjects->fname); ?> <?php echo e($view_studentsubjects->middlename); ?> <?php echo e($view_studentsubjects->surname); ?> in <?php echo e($view_studentsubjects->classname); ?> at <?php echo e($view_studentsubjects->section); ?> study center <?php echo e($view_studentsubjects->term); ?></span>
            </div>


            <!-- Main content -->
            <div class="invoice p-3 mb-3">
              <!-- title row -->
              <div class="row">
                <div class="col-12">
                    <h2 class="page-header">
                        <small class="float-right"><?php echo e($view_studentsubjects->created_at->format('D d, M Y, H:i')); ?></small>
                    </h2>
                </div>
                <!-- /.col -->
              </div>
              <!-- info row -->
              <div class="row invoice-info">
                <div class="col-lg-2 col-md-3 col-sm-4 invoice-col">
                    <img style="width: 100px; height: 100px;" src="<?php echo e(asset('images/sch14.png')); ?>" alt=""> <br>

                </div> 
                <!-- /.col -->
               <div class="col-lg-8 col-md-3 col-sm-4 invoice-col">
                <h1> <strong>GOLDERN  DESTINY ACADEMY </strong></h1>
              
                <p>Golden Destiny Academy Road.
                  Off Senator Akon Eyakenyi Street,
                  Off General Edet Akpan Ave, 520101, Uyo</p>
                   
                </div>
                <!-- /.col -->
                <div class="col-lg-2 col-md-3 col-sm-4 invoice-col">
                    <img style="width: 70%; height: 100px;" src="<?php echo e(URL::asset("/public/../$view_studentsubjects->images")); ?>" alt="">
                </div>
                <!-- /.col -->
              </div>
              <!-- /.row -->

              <!-- Table row -->
              <div class="row">
                <div class="col-12 table-responsive">
                  <?php if($view_studentsubjects->section === 'Primary'): ?>
                      <form action="" method="post">
                        <table class="table table-striped">
                            <thead>
                            <tr>
                              
                              <th>Subjects</th>
                              <th>Ca 1</th>
                              <th>Ca 2</th>
                              <th>Ca 3</th>
                              <th>Exams</th>
                              
                            </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $view_subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $view_subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <?php if($view_subject->section == 'Primary'): ?>
                                  <tr>
                                    <td><?php echo e($view_subject->subjectname); ?></td>
                                    <td><input type="number" class="form-control" name="test_1" placeholder="Test 1"></td>
                                    <td><input type="number" class="form-control" name="test_2" placeholder="Test 2"></td>
                                    <td><input type="number" class="form-control" name="test_3" placeholder="Test 3"></td>
                                    <td><input type="number" class="form-control" name="exams" placeholder="Exams"></td>
                                  </tr>
                                  <?php else: ?>
                                  <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                          </table>
                      </form>
                  <?php else: ?>
                      
                  <?php endif; ?>


                </div>
                <!-- /.col -->
              </div>
              <!-- /.row -->

              <div class="row">
                <!-- accepted payments column -->
                
                <!-- /.col -->
                
                <!-- /.col -->
              </div>
              <!-- /.row -->

              <!-- this row will not appear when printing -->
              <div class="row no-print">
                <div class="col-12">
                  <a href="invoice-print.html" target="_blank" class="btn btn-default"><i class="fas fa-print"></i> Print</a>
                  <button type="button" class="btn btn-success float-right"><i class="far fa-credit-card"></i> Submit
                    Payment
                  </button>
                  <button type="button" class="btn btn-primary float-right" style="margin-right: 5px;">
                    <i class="fas fa-download"></i> Generate PDF
                  </button>
                </div>
              </div>
            </div>
            <!-- /.invoice -->
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
 <?php echo $__env->make('dashboard.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\goldendays-master\resources\views/dashboard/studentsubjectbyhead.blade.php ENDPATH**/ ?>
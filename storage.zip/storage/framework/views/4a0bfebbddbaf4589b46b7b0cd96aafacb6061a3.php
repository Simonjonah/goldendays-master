<!DOCTYPE html>
<html>
<head>
    <title>Brixtonn Terminal Result</title>
    <link rel="stylesheet" href="../../assets/dist/css/adminlte.min.css">
    
</head>
<style>
    table{
    width:200px;
    height:auto;
    table-layout:fixed;
}
</style>
<body>
  
  
    <table class="table table-bordered">

        <tr>
            <th style="width:783px; height:18px; border:1px solid black;">Test</th>
            <th style="width:783px; height:18px; border:1px solid black;">Exams</th>
            <th style="width:783px; height:18px; border:1px solid black;">Total</th>
            <th style="width:783px; height:18px; border:1px solid black;">Grade</th>
        </tr>
        <?php $__currentLoopData = $getyour_results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $getyour_result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($getyour_result->test_1 + $getyour_result->test_2 + $getyour_result->test_3); ?></td>
            <td><?php echo e($getyour_result->exams); ?></td>
            <td><?php echo e($getyour_result->test_1 + $getyour_result->test_2 + $getyour_result->test_3 + $getyour_result->exams); ?></td>
            <td><?php if($getyour_result->test_1 + $getyour_result->test_2 + $getyour_result->test_3 + $getyour_result->exams > 69): ?>
                <p>A</p>
               
                <?php elseif($getyour_result->test_1 + $getyour_result->test_2 + $getyour_result->test_3 + $getyour_result->exams > 59): ?>
                <p>B</p>
                <?php elseif($getyour_result->test_1 + $getyour_result->test_2 + $getyour_result->test_3 + $getyour_result->exams > 49): ?>
                <p>c</p>
                <?php elseif($getyour_result->test_1 + $getyour_result->test_2 + $getyour_result->test_3 + $getyour_result->exams > 44): ?>
                <p>D</p>
                <?php elseif($getyour_result->test_1 + $getyour_result->test_2 + $getyour_result->test_3 + $getyour_result->exams > 40): ?>
                <p>E</p>
                <?php elseif($getyour_result->test_1 + $getyour_result->test_2 + $getyour_result->test_3 + $getyour_result->exams > 39): ?>
                <p>F</p>
                <?php else: ?>
                <p>F</p>
              <?php endif; ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
  
</body>
</html><?php /**PATH C:\xampp\htdocs\goldendays-master\resources\views/dashboard/pdf.blade.php ENDPATH**/ ?>
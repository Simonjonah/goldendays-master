<!-- Main Sidebar Container -->
<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="<?php echo e(route('admin.home')); ?>" class="brand-link">
      <img src="<?php echo e(asset('assets/dist/img/AdminLTELogo.png')); ?>" alt="AdminLTE Logo" class="brand-image "
           style="opacity: .8">
      <span class="brand-text font-weight-light"><br>GOLDENDESTINY SCHOOLS </span>
    </a>
    
      <?php
        use App\Models\Classname;
          $view_clesses = Classname::all();
      ?>
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          <img src="<?php echo e(asset('/public/../'.Auth::guard('admin')->user()->images)); ?>" class="img-circle elevation-2" alt="User Image">
        </div>
        <div class="info">
          <a href="<?php echo e(route('admin.profile')); ?>" class="d-block"><?php echo e(Auth::guard('admin')->user()->name); ?></a>
        </div>
      </div>

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item has-treeview menu-open">
            <a href="#" class="nav-link active">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
                Dashboard
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(route('admin.home')); ?>" class="nav-link active">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Dashboard </p>
                </a>
              </li>
              
            </ul>
          </li>
          <li class="nav-item">
            <a href="<?php echo e(route('admin.profile')); ?>" class="nav-link">
              <i class="nav-icon fas fa-user"></i>
              <p>
                Profile
                <span class="right badge badge-danger">New</span>
              </p>
            </a>
          </li>
          <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-th"></i>
              <p>
                Add Classes
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <li class="nav-item">
                  <a href="<?php echo e(route('admin.addclass')); ?>" class="nav-link">
                    <i class="far fa-circle nav-icon"></i>
                    <p>Add Class</p>
                  </a>
                </li>

                <li class="nav-item">
                  <a href="<?php echo e(route('admin.viewclassestables')); ?>" class="nav-link">
                    <i class="far fa-circle nav-icon"></i>
                    <p>View Classes</p>
                  </a>
                </li>
              </li>
            </ul>
          </li>


         <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-th"></i>
              <p>
                Class Activities
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <li class="nav-item">
                  <a href="<?php echo e(route('admin.addclassactivitiesad')); ?>" class="nav-link">
                    <i class="far fa-circle nav-icon"></i>
                    <p>Add Class Activities</p>
                  </a>
                </li>

                <li class="nav-item">
                  <a href="<?php echo e(route('admin.viewclassactivitiesads')); ?>" class="nav-link">
                    <i class="far fa-circle nav-icon"></i>
                    <p>View Class Activities</p>
                  </a>
                </li>
              </li>
            </ul>
          </li> 



          
          <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-users"></i>
              <p>
                Students
                <i class="fas fa-angle-left right"></i>
                <span class="badge badge-info right"></span>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(route('admin.addparent')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Register Parents</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(route('admin.viewparents')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>View Parents</p>
                </a>
              </li>

              <li class="nav-item">
                <a href="<?php echo e(route('admin.adminprogress')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Pimary Pupils</p>
                </a>
              </li>
              
              
             
              
              <li class="nav-item">
                <a href="<?php echo e(route('admin.admittedstudents')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Secondary Students</p>
                </a>
              </li>
             
            </ul>
          </li>
          <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-copy"></i>
              <p>
                Classes Manage
                <i class="fas fa-angle-left right"></i>
                <span class="badge badge-info right">6</span>
              </p>
            </a>
            <ul class="nav nav-treeview">
            
              <li class="nav-item has-treeview">
                <a href="#" class="nav-link">
                  <i class="nav-icon far fa-plus-square"></i>
                  <p>
                    Classes
                    <i class="fas fa-angle-left right"></i>
                  </p>
                </a>
                <ul class="nav nav-treeview">
                  <?php $__currentLoopData = $view_clesses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $view_clesse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li class="nav-item">
                    <a href="<?php echo e(url('admin/classrooms/'.$view_clesse->classname)); ?>" class="nav-link">
                      <i class="far fa-circle nav-icon"></i>
                      <p><?php echo e($view_clesse->classname); ?></p>
                    </a>
                  </li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
                 
                </ul>
              </li>
            </ul>
             
          <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-chart-pie"></i>
              <p>
                Subjects
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(route('admin.addsubject')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Add Subject</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(route('admin.nurserysubjects')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Assign Prim & Nursery Sub</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(route('admin.viewsubject')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Assign Secondary School Sub</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(route('admin.teachertosubjects')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Teacher to Subject</p>
                </a>
              </li>

              <li class="nav-item">
                <a href="<?php echo e(route('admin.allsubjects')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>All Subject</p>
                </a>
              </li>
              
            </ul>
          </li>
          <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-chart-pie"></i>
              <p>
                Session
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(route('admin.addsession')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Add Session</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(route('admin.viewsession')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>View Session</p>
                </a>
              </li>
              
            </ul>
          </li>

          <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-users"></i>
              <p>
                Teachers
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(route('admin.viewteachers')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>View Teachers</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(route('admin.approveteachers')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>View Approve Teachers </p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(route('admin.suspendedteachers')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>View  Suspended Teachers </p>
                </a>
              </li>

              <li class="nav-item">
                <a href="<?php echo e(route('admin.sackedteachers')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>View  Sacked Teachers </p>
                </a>
              </li>

              <li class="nav-item">
                <a href="<?php echo e(route('admin.queriedteachers')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>View  Queried Teachers </p>
                </a>
              </li>

              <li class="nav-item">
                <a href="<?php echo e(route('admin.queriedteachersreply')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>View  Query Replied </p>
                </a>
              </li>

              <li class="nav-item">
                <a href="<?php echo e(route('admin.allteachers')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>View all Teachers </p>
                </a>
              </li>
            
              <li class="nav-item">
                <a href="<?php echo e(route('admin.primaryteachers')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Primary Teachers </p>
                </a>
              </li>

              <li class="nav-item">
                <a href="<?php echo e(route('admin.secondaryteachers')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Secondary Teachers </p>
                </a>
              </li>
              
            </ul>

          </li>

          <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
              <i class="nav-icon far fa-plus-square"></i>
              <p>
                Payments 
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
             <ul class="nav nav-treeview">
              
              <li class="nav-item">
                <a href="<?php echo e(url('admin/viewallpaymentsad')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>View All Payments</p>
                </a>
              </li>

              <?php $__currentLoopData = $view_clesses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $view_clesse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li class="nav-item">
                <a href="<?php echo e(url('admin/classpaymentad/'.$view_clesse->classname)); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p><?php echo e($view_clesse->classname); ?></p>
                </a>
              </li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          </li>


          <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
              <i class="nav-icon far fa-plus-square"></i>
              <p>
                Generate Payments 
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
             <ul class="nav nav-treeview">
              <li class="nav-item">
             
                <a href="<?php echo e(route('admin.addschoolfeespaymentad')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Add School Fees</p>
                </a>
              </li>

              <li class="nav-item">
             
                <a href="<?php echo e(route('admin.addbusfeespaymentad')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Bus Fees</p>
                </a>
              </li>

              <li class="nav-item">
             
                <a href="<?php echo e(route('admin.addfeedingfeespaymentad')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Add Feeding Fees</p>
                </a>
              </li>

              <li class="nav-item">
             
                <a href="<?php echo e(route('admin.addpartyfeespaymentad')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Add Party Fees</p>
                </a>
              </li>
              
             

              <li class="nav-item">
                <a href="<?php echo e(url('admin/viewallfees')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>View All Fees</p>
                </a>
              </li>

            </ul>
          </li>
          
          <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
              <i class="nav-icon far fa-plus-square"></i>
              <p>
                Notification 
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
             <ul class="nav nav-treeview">
              <li class="nav-item">
             
                <a href="<?php echo e(route('admin.addnotification')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Add notification</p>
                </a>
              </li>
              


              <li class="nav-item">
                <a href="<?php echo e(url('admin/viewnotification')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>View Notification</p>
                </a>
              </li>
            </ul>
          </li>
          
          <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
              <i class="nav-icon far fa-plus-square"></i>
              <p>
                Result Management 
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
             <ul class="nav nav-treeview">
              <?php $__currentLoopData = $view_clesses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $view_clesse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li class="nav-item">
                <a href="<?php echo e(url('admin/viewclassresults/'.$view_clesse->classname)); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p><?php echo e($view_clesse->classname); ?></p>
                </a>
              </li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
              <li class="nav-item">
             
                <a href="<?php echo e(route('admin.viewresultbyadmin')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>View Results</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(url('admin/viewapproveresultsbyad')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>View Approved Results</p>
                </a>
              </li>
               
            </ul>
          </li>

          <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
              <i class="nav-icon far fa-plus-square"></i>
              <p>
                Add Result 
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
             <ul class="nav nav-treeview">
              
              <?php $__currentLoopData = $view_clesses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $view_clesse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li class="nav-item">
                <a href="<?php echo e(url('admin/addresultsad/'.$view_clesse->classname)); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p><?php echo e($view_clesse->classname); ?></p>
                </a>
              </li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               
            </ul>
          </li>
         
          <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-th"></i>
              <p>
                Lesson Note Section
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                
                <li class="nav-item">
                  <a href="<?php echo e(route('admin.viewlessonnotesad')); ?>" class="nav-link">
                    <i class="far fa-circle nav-icon"></i>
                    <p>View Lesson Notes</p>
                  </a>
                </li>
              </li>

              
            </li>
            </ul>
          </li>

          <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-th"></i>
              <p>
                Roles
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
               
                <li class="nav-item">
                  <a href="<?php echo e(route('admin.viewroles')); ?>" class="nav-link">
                    <i class="far fa-circle nav-icon"></i>
                    <p>View Role</p>
                  </a>
                </li>
              </li>
            </ul>
          </li>


         


          <li class="nav-item has-treeview menu-open">
            <a href="#" class="nav-link active">
              <i class="nav-icon fas fa-book"></i>
              <p>
                Logout
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(route('admin.logout')); ?>" class="nav-link active">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Logout</p>
                </a>
              </li>
           
            </ul>
          </li>

          
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>
<?php /**PATH C:\xampp\htdocs\goldendays-master\resources\views/dashboard/admin/sidebar.blade.php ENDPATH**/ ?>
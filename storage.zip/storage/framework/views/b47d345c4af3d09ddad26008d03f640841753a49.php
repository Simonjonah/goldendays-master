<!-- Main Sidebar Container -->
<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="<?php echo e(url('web/home')); ?>" class="brand-link">
      <img src="<?php echo e(asset('assets/dist/img/AdminLTELogo.png')); ?>" alt="webLTE Logo" class="brand-image "
           style="opacity: .8">
      <span class="brand-text font-weight-light">Golden Academy</span>
    </a>

    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          <img src="<?php echo e(asset('/public/../'.Auth::guard('web')->user()->images)); ?>" class="img-circle elevation-2" alt="User Image">
        </div>
        <div class="info">
          <a href="<?php echo e(url('web/profile/'.Auth::guard('web')->user()->ref_no11)); ?>" class="d-block"><?php echo e(Auth::guard('web')->user()->fname); ?></a>
        </div>
      </div>

      <!-- Sidebar Menu -->
      <?php if(Auth::guard('web')->user()->status == null): ?>
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
         
          <li class="nav-item has-treeview menu-open">
            <a href="#" class="nav-link active">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
                Dashboard
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(url('web/home')); ?>" class="nav-link active">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Dashboard </p>
                </a>
              </li>
              
            </ul>
          </li>
          
          <li class="nav-item">
            <a href="<?php echo e(url('web/profile/'.Auth::guard('web')->user()->ref_no1)); ?>" class="nav-link">
              <i class="nav-icon fas fa-user"></i>
              <p>
                Profile
                <span class="right badge badge-danger">New</span>
              </p>
            </a>
          </li>
          <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-copy"></i>
              <p>
                Pay Fees <?php echo e(Auth::guard('web')->user()->classname); ?>

                <i class="fas fa-angle-left right"></i>
                <span class="badge badge-info right">6</span>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(url('payment')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Pioneer Term</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(url('payment')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Pensulate Term</p>
                </a>
              </li>

              <li class="nav-item">
                <a href="<?php echo e(url('payment')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Premium Term</p>
                </a>
              </li>

              <li class="nav-item">
                <a href="<?php echo e(url('payment')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Pay All Term</p>
                </a>
              </li>
             
            </ul>
          </li>

          

          <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-chart-pie"></i>
              <p>
                Payments History
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(url('web.paymenthistory')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Payments History</p>
                </a>
              </li>
            
            </ul>
          </li>
          
          <li class="nav-item has-treeview menu-open">
            <a href="#" class="nav-link active">
              <i class="nav-icon fas fa-book"></i>
              <p>
                Logout
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(route('web.logout')); ?>" class="nav-link active">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Logout</p>
                </a>
              </li>
           
            </ul>
          </li>
         
        </ul>
      </nav>
      <?php elseif(Auth::guard('web')->user()->status == 'reject'): ?>
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
         
          <li class="nav-item has-treeview menu-open">
            <a href="#" class="nav-link active">
              <i class="nav-icon fas fa-book"></i>
              <p>
                Logout
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(route('web.logout')); ?>" class="nav-link active">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Logout</p>
                </a>
              </li>
           
            </ul>
          </li>
         
        </ul>
      </nav>
        
      <?php elseif(Auth::guard('web')->user()->status == 'suspend'): ?>
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
         
          <li class="nav-item has-treeview menu-open">
            <a href="#" class="nav-link active">
              <i class="nav-icon fas fa-book"></i>
              <p>
                Logout
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(route('web.logout')); ?>" class="nav-link active">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Logout</p>
                </a>
              </li>
           
            </ul>
          </li>
         
        </ul>
      </nav>
       
      <?php elseif(Auth::guard('web')->user()->status == 'admitted'): ?>
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item has-treeview menu-open">
            <a href="#" class="nav-link active">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
                Dashboard
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(url('web/home')); ?>" class="nav-link active">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Dashboard </p>
                </a>
              </li>
              
            </ul>
          </li>
          <li class="nav-item">
            <a href="<?php echo e(url('web/profile/'.Auth::guard('web')->user()->ref_no1)); ?>" class="nav-link">
              <i class="nav-icon fas fa-user"></i>
              <p>
                Profile
                <span class="right badge badge-danger">New</span>
              </p>
            </a>
          </li>
          <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-copy"></i>
              <p>
                Pay Fees <?php echo e(Auth::guard('web')->user()->classname); ?>

                <i class="fas fa-angle-left right"></i>
                <span class="badge badge-info right">6</span>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(url('web/payment')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Pioneer Term</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(url('web/payment')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Pensulate Term</p>
                </a>
              </li>

              <li class="nav-item">
                <a href="<?php echo e(url('payment')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Premium Term</p>
                </a>
              </li>

              <li class="nav-item">
                <a href="<?php echo e(url('payment')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Pay All Term</p>
                </a>
              </li>
             
            </ul>
          </li>
          <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-chart-pie"></i>
              <p>
                Payments History
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(url('web.paymenthistory')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Payments History</p>
                </a>
              </li>
            
            </ul>
          </li>
          
          
          <li class="nav-header">ADMIMISSION</li>
          <li class="nav-item">
            <a href="<?php echo e(url('web/admisionletter')); ?>" class="nav-link">
              <i class="nav-icon fas fa-file"></i>
              <p>Admission Letter</p>
            </a>
          </li>



          <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-book"></i>
              <p>
                Check Result
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(url('web/checkresult')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Your Results</p>
                </a>
              </li>

            </ul>
          </li>
          <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-th"></i>
              <p>
                My Teacher 
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <li class="nav-item">
                  <a href="<?php echo e(url('web/myprogram')); ?>" class="nav-link">
                    <i class="far fa-circle nav-icon"></i>
                    <p>My Teacher</p>
                  </a>
                </li>
              </li>
            

            </ul>
          </li>

          
          <li class="nav-item has-treeview menu-open">
            <a href="#" class="nav-link active">
              <i class="nav-icon fas fa-book"></i>
              <p>
                Logout
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(route('web.logout')); ?>" class="nav-link active">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Logout</p>
                </a>
              </li>
           
            </ul>
          </li>
         
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
     
   

      <?php elseif(Auth::guard('web')->user()->status == 'teacher' && Auth::guard('web')->user()->role == 'approved'): ?>
      
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          
          <li class="nav-item has-treeview menu-open">
            <a href="#" class="nav-link active">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
                Dashboard Teacher
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(url('/web/home')); ?>" class="nav-link active">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Dashboard </p>
                </a>
              </li>
              
            </ul>
          </li>
          <li class="nav-item">
            <a href="<?php echo e(url('web/profile/'.Auth::guard('web')->user()->ref_no1)); ?>" class="nav-link">
              <i class="nav-icon fas fa-user"></i>
              <p>
                Profile
                <span class="right badge badge-danger">New</span>
              </p>
            </a>
          </li>
          <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-copy"></i>
              <p>
                Classes
                <i class="fas fa-angle-left right"></i>
                <span class="badge badge-info right">6</span>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(url('/web/firsterm')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>First Term</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(url('/web/secondterm')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Second Term</p>
                </a>
              </li>

              <li class="nav-item">
                <a href="<?php echo e(url('/web/thirdterm')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Third Term</p>
                </a>
              </li>

            </ul>
          </li>
          <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-chart-pie"></i>
              <p>
                Results Management
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(url('web/firstermresults')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>First Term Result</p>
                </a>
              </li>

              <li class="nav-item">
                <a href="<?php echo e(url('web/secondtermresults')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Second Term Result</p>
                </a>
              </li>

              <li class="nav-item">
                <a href="<?php echo e(url('web/thirdtermresults')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Third Term Result</p>
                </a>
              </li>
            
            </ul>
          </li>
          
          
          
          <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-book"></i>
              <p>
                Query
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(url('web/checkyourquery')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Your Query</p>
                </a>
              </li>

              <li class="nav-item">
                <a href="<?php echo e(url('web/queryrepliedview')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p> Query Replied</p>
                </a>
              </li>
              
            </ul>
          </li>

          <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-book"></i>
              <p>
                Class Activities
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(url('web/addaclassctivities')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Add Class Activities</p>
                </a>
              </li>

              <li class="nav-item">
                <a href="<?php echo e(url('web/viewclassactivities')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p> View Activities</p>
                </a>
              </li>
              
              <li class="nav-item">
                <a href="<?php echo e(url('web/sendtospecificparent')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Add Class Activities to Spec</p>
                </a>
              </li>

              <li class="nav-item">
                <a href="<?php echo e(url('web/viewspecific')); ?>" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>View Activities to Spec</p>
                </a>
              </li>

            </ul>
          </li>
          
          <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-th"></i>
              <p>
                My Assigned Subjects 
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <li class="nav-item">
                  <a href="<?php echo e(url('web/mysubjects')); ?>" class="nav-link">
                    <i class="far fa-circle nav-icon"></i>
                    <p>My Subjects</p>
                  </a>
                </li>

                <?php if(Auth::guard('web')->user()->promotion == 'Primary Head'): ?>
                <li class="nav-item">
                  <a href="<?php echo e(url('web/primaryheads')); ?>" class="nav-link">
                    <i class="far fa-circle nav-icon"></i>
                    <p>Primary Head</p>
                  </a>
                </li>
                <?php else: ?>
                <li class="nav-item">
                  <a href="<?php echo e(url('web/highschools')); ?>" class="nav-link">
                    <i class="far fa-circle nav-icon"></i>
                    <p>Secondary Schools</p>
                  </a>
                </li>
              </li>
                <?php endif; ?>
                

            </ul>
          </li>

          
          <li class="nav-item has-treeview menu-open">
            <a href="#" class="nav-link active">
              <i class="nav-icon fas fa-book"></i>
              <p>
                Logout
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(route('web.logout')); ?>" class="nav-link active">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Logout</p>
                </a>
              </li>
           
            </ul>
          </li>
         
        </ul>
      </nav> 
      <?php else: ?>

      <h1>no</h1>
      <?php endif; ?>
    </div>
    <!-- /.sidebar -->
  </aside>
<?php /**PATH C:\xampp\htdocs\goldendays-master\resources\views/dashboard//sidebar.blade.php ENDPATH**/ ?>